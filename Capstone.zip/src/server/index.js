var path = require('path')
const express = require('express')
const bodyParser = require('body-parser')  //this is a must
const fetch = require('node-fetch'); //this is a must
const mockAPIResponse = require('./mockAPI.js')

const app = express()
const cors = require('cors');
app.use(cors());

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json());
app.use(express.static('dist'))

console.log(__dirname)

var projectData={};
app.get('/', function (req, res) {
    //res.sendFile('dist/index.html')
    res.sendFile(path.resolve('src/client/views/index.html'))
})


//to do a test
app.get('/test', (req, res) => {
    res.send(mockAPIResponse)
})

// GET route, usd to get data from server. 
app.get("/get", getData);
function getData(req, res) {
    console.log("server sending back data...");
	res.send(projectData);  
}

//post data to server
app.post("/post", postData);
function postData(req, res) {
	console.log("saving to local, here is data need to be saved",req.body);
	projectData = req.body;
	res.send(projectData);
}


// designates what port the app will listen to for incoming requests
app.listen(8080, function () {
    console.log('Travel app listening on port 8080!')
})



module.exports = {postData, getData}

