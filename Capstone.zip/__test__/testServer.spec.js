// Import the js file to test
import { postData, getData} from "../src/server/index.js"

describe("Testing ..........", () => {
    test("Testing postData & getData", () => {
        expect(postData).toBeDefined();
        expect(getData).toBeDefined();           
})});